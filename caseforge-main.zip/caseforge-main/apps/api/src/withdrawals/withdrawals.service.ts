import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
  OnModuleDestroy,
} from '@nestjs/common';
import { Queue } from 'bullmq';
import { ErrorCode, parseRedisUrl, type WithdrawalProvider } from '@caseforge/shared';
import { PrismaService } from '../common/prisma.service';
import { SettingsService } from '../common/settings.service';
import { KycService } from '../kyc/kyc.service';
import { badRequest } from '../common/app-error';

export const WITHDRAWAL_QUEUE = 'withdrawals';

/** How many times the worker retries an offer before the request goes FAILED. */
const MAX_ATTEMPTS = 3;

@Injectable()
export class WithdrawalsService implements OnModuleDestroy {
  private readonly logger = new Logger(WithdrawalsService.name);
  private readonly queue: Queue;

  constructor(
    private readonly prisma: PrismaService,
    private readonly settings: SettingsService,
    private readonly kyc: KycService,
  ) {
    this.queue = new Queue(WITHDRAWAL_QUEUE, {
      // The whole URL, not just its host and port: a deployment whose Redis
      // wants a password or lives in a numbered database would otherwise get a
      // queue that cannot reach it, or one writing where nothing reads.
      connection: parseRedisUrl(process.env.REDIS_URL ?? 'redis://localhost:6380'),
      defaultJobOptions: {
        attempts: MAX_ATTEMPTS,
        backoff: { type: 'exponential', delay: 5000 },
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    });
  }

  /**
   * The queue holds its own Redis connection and keeps the process alive. A
   * long-running API never notices; a one-shot script built on the same
   * AppModule simply hangs after finishing its work.
   */
  async onModuleDestroy(): Promise<void> {
    await this.queue.close().catch(() => undefined);
  }

  /**
   * Creates a withdrawal request.
   *
   * Items move to LOCKED in the same transaction that creates the request:
   * otherwise the player can sell an item while the delivery is in flight, and
   * the site hands out something it has already paid a balance for.
   *
   * The delivery channel is resolved here and stored on the request rather than
   * read again by the worker. An operator switching from the market to the bot
   * farm changes what happens to the next request, never to one already being
   * paid for.
   */
  async request(userId: string, inventoryItemIds: string[]) {
    const uniqueIds = [...new Set(inventoryItemIds)];

    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { tradeUrl: true, isBanned: true },
    });
    if (!user) throw new NotFoundException('User not found');
    if (user.isBanned) throw badRequest(ErrorCode.ACCOUNT_BANNED, 'Account is banned');
    if (!user.tradeUrl)
      throw badRequest(ErrorCode.TRADE_URL_MISSING, 'Set your Steam trade URL first');

    const provider = await this.settings.read<WithdrawalProvider>('withdrawals.provider');

    const withdrawal = await this.prisma.$transaction(async (tx) => {
      const items = await tx.inventoryItem.findMany({
        where: { id: { in: uniqueIds }, userId, status: 'AVAILABLE' },
        include: { item: { select: { marketHashName: true } } },
      });
      if (items.length !== uniqueIds.length) {
        throw badRequest(ErrorCode.ITEM_UNAVAILABLE, 'Some items are not available for withdrawal');
      }

      const totalValue = items.reduce((sum, i) => sum + i.acquiredPrice, 0);

      // The identity gate, checked with the total in hand and before anything
      // is locked. Inside the transaction so a player cannot get two requests
      // past the same remaining allowance by sending them at once.
      const verdict = await this.kyc.mayWithdraw(userId, totalValue);
      if (!verdict.allowed) {
        throw badRequest(ErrorCode.KYC_REQUIRED, verdict.reason ?? 'Identity verification required');
      }

      const created = await tx.withdrawal.create({
        data: { userId, totalValue, tradeUrl: user.tradeUrl!, status: 'PENDING', provider },
      });

      // The request's own record of what it was for. Written here, in the same
      // transaction as the lock, because this is the only moment at which the
      // answer is certainly known: from the next status change onwards an item
      // may have been given back, and the lock that would have told us is the
      // first thing a refund clears.
      await tx.withdrawalItem.createMany({
        data: items.map((inv) => ({
          withdrawalId: created.id,
          inventoryItemId: inv.id,
          itemId: inv.itemId,
          marketHashName: inv.item.marketHashName,
          price: inv.acquiredPrice,
        })),
      });

      const locked = await tx.inventoryItem.updateMany({
        where: { id: { in: uniqueIds }, userId, status: 'AVAILABLE' },
        data: { status: 'LOCKED', withdrawalId: created.id },
      });
      if (locked.count !== uniqueIds.length) {
        // Someone claimed an item between findMany and updateMany — roll the
        // whole transaction back, no request is created.
        throw badRequest(ErrorCode.ITEMS_CHANGED, 'Items changed, please try again');
      }

      return created;
    });

    // jobId = the request id: a repeat call creates no second offer even if
    // the client fires the request twice.
    await this.queue.add('process', { withdrawalId: withdrawal.id }, { jobId: withdrawal.id });

    this.logger.log(`Withdrawal ${withdrawal.id} queued`);
    return withdrawal;
  }

  /**
   * The player's requests.
   *
   * Purchases come along because on the market channel a request is not one
   * event but several: "two of your three skins have arrived, the third is
   * still with its seller" is the only honest thing to show, and it cannot be
   * said from the request's own status alone.
   */
  async list(userId: string) {
    const withdrawals = await this.prisma.withdrawal.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        items: { orderBy: { createdAt: 'asc' } },
        purchases: {
          select: {
            id: true,
            inventoryItemId: true,
            marketHashName: true,
            status: true,
            tradeOfferId: true,
            deliveredAt: true,
          },
        },
      },
    });

    return withdrawals.map((w) => ({
      ...w,
      // The market's own prices and our ceiling are the site's business, not
      // the player's — they see whether their item is coming, not what it cost
      // to get it to them.
      purchases: w.purchases.map((p) => ({
        inventoryItemId: p.inventoryItemId,
        marketHashName: p.marketHashName,
        status: p.status,
        tradeOfferId: p.tradeOfferId,
        deliveredAt: p.deliveredAt,
      })),
    }));
  }

  /**
   * Cancels a request, while nothing has left yet.
   *
   * Only a PENDING request qualifies, and the window is deliberately narrow: on
   * the bot channel the offer is already with the player afterwards, and on the
   * market channel the money has already been spent on a skin that is on its
   * way to them. Neither is something the site can take back by writing to its
   * own database.
   */
  async cancel(userId: string, withdrawalId: string) {
    return this.prisma.$transaction(async (tx) => {
      const withdrawal = await tx.withdrawal.findFirst({
        where: { id: withdrawalId, userId },
      });
      if (!withdrawal) throw new NotFoundException('Request not found');
      if (withdrawal.status !== 'PENDING') {
        throw badRequest(
          ErrorCode.WITHDRAWAL_NOT_CANCELLABLE,
          'This request can no longer be cancelled',
        );
      }

      const cancelled = await tx.withdrawal.updateMany({
        where: { id: withdrawalId, status: 'PENDING' },
        data: { status: 'CANCELLED' },
      });
      if (cancelled.count === 0) {
        throw badRequest(
          ErrorCode.WITHDRAWAL_NOT_CANCELLABLE,
          'The request is already being processed',
        );
      }

      // Only the lock is released. The lines stay, so a cancelled request can
      // still say what it was for.
      await tx.inventoryItem.updateMany({
        where: { withdrawalId, userId },
        data: { status: 'AVAILABLE', withdrawalId: null },
      });

      return { ok: true as const };
    });
  }
}
