# Contributing

Thanks for taking a look. Issues and pull requests are both welcome.

## Getting it running

Requires Node ≥ 22, pnpm 11 and Docker.

```bash
cp .env.example .env       # no editing needed for a local run
pnpm setup                 # install + docker + shared build + migrations + seed
pnpm dev                   # api on :4000, web on :3000
```

`pnpm setup` seeds only the demo administrator. The catalogue of themed cases is
populated separately by `pnpm seed:cases`, which talks to the Steam market and
takes about ten minutes.

## Before opening a pull request

```bash
pnpm typecheck     # every package, strict
pnpm test          # unit tests: provable fairness, ticket ranges, balancing, upgrade odds
pnpm format        # prettier
```

`pnpm test:smoke` is the end-to-end pass. It needs the infrastructure up and the
API running, and it is worth running for anything that touches money, openings
or roles. `pnpm test:smoke:battles` covers case battles and referrals.

`pnpm test:load` generates load against a running API — worth a before-and-after
run for anything on a hot read path. Its numbers are comparative, not capacity:
the generator shares the machine with what it measures. Section 10 of the
architecture document describes the pooled-and-replicated setup it is meant to
be pointed at (`pnpm infra:up:scale`).

## What the review looks for

- **Money is integer minor units.** No floats anywhere near a balance, an item
  price or a case price, and no ledger entry ever stores a converted amount. The
  currency switch is display only.
- **Every balance change goes through `Transaction`.** The nightly
  reconciliation compares balances against the ledger; a direct write breaks it.
- **The active server seed never leaves the server** until it is rotated.
  Anything that could leak it before reveal is a blocker.
- **Shared code stays isomorphic.** `node:crypto` lives behind the
  `@caseforge/shared/node` subpath — importing it from the main entry point
  breaks the web build.
- **Code and comments are in English.** Interface strings go in
  `packages/shared/src/i18n.ts` with both RU and EN, and server errors carry a
  machine-readable `code` alongside the message.
- **The read client is for reads that tolerate lag.** `PRISMA_READ` may serve a
  report, the catalogue, the lobby or the drop feed; it must never serve what
  the player asking has just written, and nothing inside a transaction.
- **Money is reported from the ledger, never from an analytics event.** The
  event stream is for what the database cannot answer — arrivals, sources, page
  views, abandoned clicks. A second source for a number that already exists is a
  second number, and the ledger is the one that has to win.
- **Appearance settings cannot reach the odds.** A new knob that changes what a
  player can win belongs in its own group, not next to the palette.
- New rules around openings, odds or payouts come with a test.

## Scope

The roadmap lives in section 14 of [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
Payments, item deposits and KYC are all unimplemented on purpose — if you want to
take one on, open an issue first so the design can be agreed before the code.
